local forceFirstPersonInVehicle = true

CreateThread(function()
    while true do
        Wait(0)

        if forceFirstPersonInVehicle then
            local ped = PlayerPedId()

            if IsPedInAnyVehicle(ped, false) then
                -- 4 = first person vehicle camera
                if GetFollowVehicleCamViewMode() ~= 4 then
                    SetFollowVehicleCamViewMode(4)
                end
            end
        else
            Wait(500)
        end
    end
end)